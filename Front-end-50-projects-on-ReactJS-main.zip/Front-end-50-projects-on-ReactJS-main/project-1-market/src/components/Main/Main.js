import React from 'react'

const Main = () => {
  return (
    <div className='main' >
      
    </div>
  )
}

export default Main